# Football Scouting — Capstone EPICODE

Progetto di analisi dei dati dedicato allo scouting calcistico e all’approccio Moneyball, sviluppato per il corso Data Analyst di EPICODE. La stagione di riferimento delle partite è la **2025/26**.

## Obiettivo

Individuare i calciatori da approfondire nello scouting, mettendo in relazione rendimento, età, esposizione al gioco e valore di mercato. Il report rende esplorabile la popolazione dei candidati, permette di confrontare due giocatori e presenta selezioni costruite con regole esplicite.

Il risultato è una lista di priorità da integrare con osservazione tecnica, analisi video e verifiche economiche.

## Contenuto della cartella e apertura

- **Football_Scouting.pbix**: report Power BI con modello dati, due pagine introduttive e cinque pagine analitiche.
- **data/**: le 13 tabelle CSV utilizzate dal modello.
- **README.md**: descrizione del lavoro, delle fonti e degli indicatori.

Aprire **Football_Scouting.pbix** con Microsoft Power BI Desktop. Mantenere il file e la cartella **data** nella cartella di progetto ricevuta. Il PBIX contiene i dati importati al momento del salvataggio.

## Popolazione e selezioni

L’archivio di partenza comprende 1.978 anagrafiche e un universo storico di reporting di 1.965 giocatori. La popolazione attiva V17 deriva da una longlist di 197 profili: 15 superano il tetto di 51 milioni di euro e restano nello storico; ai 182 rimanenti si aggiungono 56 profili V14 non duplicati.

Il report contiene così **238 candidati, appartenenti a 87 squadre e cinque campionati**. Il recupero dei profili V14 amplia la base: non si tratta di un imbuto che si restringe a ogni passaggio.

| Gruppo | Giocatori | Significato |
|---|---:|---|
| Candidati V17 | 238 | Base esplorabile, entro 51 milioni di euro e con almeno 900 minuti |
| Shortlist | 60 | Selezione con quote per età, macroruolo e categoria |
| Radar Moneyball | 120 | Candidati che rispettano requisiti sportivi ed economici specifici |
| Selezionati Moneyball | 16 | Profili della categoria Moneyball inclusi nella shortlist |

Shortlist e radar condividono **37 giocatori**. I 16 selezionati Moneyball appartengono a entrambi i gruppi. I conteggi delle liste non devono essere sommati.

## Fonti dei dati

| Fonte | Tipo | Impiego documentato |
|---|---|---|
| **FBref / Sports Reference** | Portale esterno di statistiche calcistiche, riutilizzato come fonte secondaria | Statistiche sportive, minuti e riferimenti alle posizioni presenti nei materiali di origine |
| **Transfermarkt** | Database esterno di profili e valutazioni di mercato, riutilizzato come fonte secondaria | Informazioni sui profili, riferimenti di ruolo e contrattuali, stime del valore di mercato |
| **Staging delle statistiche avanzate** | Tabella integrativa del database locale, con stato provvisorio | Conteggi di passaggi, dribbling, duelli aerei e altri indicatori avanzati |

SQLite, CSV e workbook sono contenitori ed esportazioni dello snapshot, non ulteriori fonti indipendenti. Il report utilizza i dati locali già integrati e non effettua raccolta in tempo reale.

La provenienza di ogni campo dello staging avanzato non è ricostruibile integralmente dai materiali disponibili. Questi indicatori sono pertanto contrassegnati come **provvisori**. Il riferimento alla stagione **2025/26** non implica che lo snapshot comprenda tutte le partite dell’intera stagione.

La granularità principale è **una riga per giocatore nello snapshot**, identificata da una chiave univoca. Per i giocatori che hanno rappresentato più club, le statistiche aggregate restano attribuite alla squadra indicata dalla fonte; non costituiscono una ricostruzione partita per partita.

## Preparazione e modellazione

**Python:** lettura del database e degli export, controllo degli identificativi, riconciliazione delle liste, gestione dei valori mancanti e preparazione delle tabelle. Gli indici V17 e le quote esplicitano il procedimento di selezione. Gli score storici sono conservati senza modificarli per favorire determinati giocatori.

**SQLite e SQL:** conservazione dello storico, collegamento delle tabelle tramite identificativo e controlli su unicità, integrità e corrispondenza tra popolazioni ed esportazioni.

**Power Query:** importazione dei CSV UTF-8, assegnazione esplicita dei tipi e conversione numerica con cultura `en-US`, coerente con il punto decimale dei file. Le celle mancanti restano null e non vengono trasformate in zeri.

**Modello Power BI:** fatto principale con 238 righe, dimensioni di giocatore, squadra, campionato, ruolo, fascia d’età e selezione, più una tabella delle componenti dello score. Le nove relazioni attive propagano i filtri dalle dimensioni ai fatti. I selettori dei due giocatori nel confronto sono disconnessi e applicati attraverso misure dedicate, mantenendo indipendenti le due scelte.

**DAX:** conteggi distinti, aggregazioni, indicatori per 90 minuti, percentuali, classifiche per ruolo, benchmark e confronto tra profili. Le misure ricalcolano i risultati nel contesto dei filtri, mentre i benchmark di ruolo restano fissi sul pool V17.

## Performance Score e Performance Percentile

Il **Performance Score V10** è il punteggio sportivo composito originale, su scala **0–100**. Riassume le componenti previste per il macroruolo:

| Macroruolo | Componenti V10 disponibili |
|---|---|
| Portieri — GK | Parate, porte inviolate, protezione della porta |
| Difensori — DEF | Distribuzione, duelli aerei, iniziativa offensiva, interdizione, uno contro uno |
| Centrocampisti — MID | Creazione, distribuzione, produzione offensiva, recupero, tecnica |
| Attaccanti — ATT | Creazione, finalizzazione, gioco associativo come proxy, qualità delle occasioni, uno contro uno |

Si tratta di componenti sperimentali già presenti nella fonte. Il progetto conserva e visualizza punteggi e componenti; la documentazione disponibile non include l’intera pipeline originaria di generazione e pesatura V10. Non viene quindi rivendicata una ricostruzione completa di quei pesi.

Il **Performance Percentile** esprime la posizione relativa nella distribuzione originale dello stesso macroruolo. Un valore 90 indica una posizione intorno al novantesimo percentile del riferimento, non una probabilità del 90% di successo.

I gruppi originali di riferimento comprendono **427 attaccanti, 552 difensori, 115 portieri e 342 centrocampisti**. I percentili sono conservati e non ricalcolati sui soli 238 candidati. Nei confronti tra ruoli si privilegia il percentile: il punteggio grezzo impiega componenti differenti e non è una misura universale di abilità.

## Valore di mercato, valore atteso e Value Score

Il **valore di mercato** è la valutazione storica Transfermarkt, espressa in milioni di euro. È distinto dal prezzo effettivo di un trasferimento.

Il **valore di mercato atteso** è una stima statistica originale ottenuta con regressione ridge sul logaritmo `log(1 + valore)`, usando macroruolo, percentile performance e fascia d’età. Il progetto riutilizza la stima disponibile senza riaddestrare il modello, poiché non sono presenti tutti i coefficienti e i passaggi originari.

Il **Price Gap Log** confronta le due grandezze, espresse nella stessa unità:

`Price Gap Log = log(1 + valore atteso) − log(1 + valore di mercato)`

Un valore positivo indica un valore osservato inferiore alla stima del modello. Il **Price Advantage Percentile** colloca questo vantaggio relativo nella distribuzione del gruppo economico di riferimento.

Il **Value Score**, su scala 0–100, combina rendimento e convenienza relativa:

`Value Score = 0,70 × Performance Percentile + 0,30 × Price Advantage Percentile`

Sono mantenuti i valori V15.1 per la base storica e V14 per i profili recuperati. Il benchmark ordinario considera fascia d’età e macroruolo; per **16 candidati** il riferimento V15.1 è ampliato al macroruolo di tutte le età. Provenienza e ampiezza del riferimento sono segnalate per evitare di trattare i punteggi come perfettamente omogenei.

Un Value Score elevato indica una combinazione favorevole secondo questi riferimenti; non dimostra che il giocatore sia acquistabile a quel valore.

## Minuti e indici V17

Il **Minutes Percentile** misura l’esposizione al gioco rispetto ai candidati della stessa fascia d’età e macroruolo. I minuti vengono limitati a **2.500**; si calcola poi la percentuale dei pari con minuti limitati minori o uguali a quelli del giocatore. Sopra 2.500 minuti il contributo non aumenta.

Il campo storico `MinutesReliability` rappresenta questa regola di esposizione, non una misura statistica della certezza della valutazione.

Con **P = Performance Percentile**, **V = Value Score** e **M = Minutes Percentile**:

| Indice | Formula | Funzione |
|---|---|---|
| Performance Priority | `0,75P + 0,15V + 0,10M` | Priorità con maggior peso alla performance |
| Moneyball Index V17 | `0,35P + 0,55V + 0,10M` | Priorità che combina qualità, convenienza relativa ed esposizione |
| Balanced Priority | `0,60P + 0,30V + 0,10M` | Supporto alla selezione dei complementi |

Il Value Score contiene già performance: i due indicatori non sono indipendenti. Sostituendo la formula di V, il Moneyball Index equivale a circa **73,5% performance percentile, 16,5% vantaggio di prezzo percentile e 10% minuti percentile**, entro gli arrotondamenti della fonte. Il 55% assegnato al Value Score non rappresenta quindi il peso del solo prezzo.

Pesi, soglie e quote sono euristiche dichiarate e non sono stati dimostrati ottimali attraverso una validazione predittiva.

## Regole del radar e della shortlist

Il radar richiede **almeno 900 minuti, Performance Percentile ≥65 e Value Score ≥70**, oltre al tetto di mercato della fascia:

| Fascia d’età | Valore massimo |
|---|---:|
| Fino a 23 anni inclusi | 15 milioni di euro |
| 24–28 anni | 12 milioni di euro |
| 29–32 anni | 8 milioni di euro |
| Da 33 anni | 5 milioni di euro |

La shortlist riserva **15 posti per fascia**: due portieri, cinque difensori, cinque centrocampisti e tre attaccanti. In ciascuna fascia vengono scelti, nell’ordine:

1. **Nove Top Performance:** un portiere, tre difensori, tre centrocampisti e due attaccanti, ordinati secondo Performance Priority e i criteri di spareggio previsti.
2. **Quattro Moneyball:** scelti tra gli idonei al radar, rispettando i posti residui per ruolo. Una penalità di 1,75 punti per ogni giocatore dello stesso ruolo già scelto favorisce il bilanciamento.
3. **Due complementi tattici:** scelti con Balanced Priority e bonus di 2,5 punti per un’etichetta tattica non ancora rappresentata e un punto per un sottoruolo nuovo, rispettando le quote residue.

Il complemento tattico deriva dalle etichette disponibili e non da osservazione video. Le quote garantiscono rappresentazione, non la superiorità assoluta dei selezionati.

La prima fascia storica include i 23enni. Il filtro **Under 23** del report significa invece età strettamente inferiore a 23 anni.

## Statistiche sportive e formule

| Statistica | Definizione e utilizzo |
|---|---|
| Età, ruolo e sottoruolo | Caratteristiche dello snapshot usate per segmentazione e selezione |
| Squadra e campionato | Contesto attribuito dalla fonte |
| Minuti e presenze | Esposizione al gioco e partecipazioni; i minuti sono il denominatore dei principali rate |
| Gol e assist | Conteggi di produzione offensiva, disponibili anche per 90 minuti |
| Tiri | Tentativi di conclusione; Shots P90 misura la frequenza per 90 minuti, non la precisione |
| Contrasti vinti | Azioni di contrasto vinte, disponibili per 90 minuti |
| Intercetti | Conteggio degli intercetti, disponibile per 90 minuti |
| Cross | Conteggio dei cross, disponibile nella misura per 90 minuti |
| Gol + assist per 90 | `90 × (gol + assist) / minuti` |
| Dribbling riusciti | Dribbling riusciti per 90 minuti esterni; indicatore provvisorio |
| Passaggi chiave | Passaggi che portano a una conclusione secondo la definizione della fonte, per 90 minuti esterni; provvisori |
| Contrasti esterni | Conteggio distinto dello staging avanzato, per 90 minuti esterni; provvisorio |
| Pass completion | `Passaggi riusciti / (riusciti + non riusciti)`; provvisorio |
| Aerial duels won | `Duelli aerei vinti / (vinti + persi)`; provvisorio |
| GK Save % | Percentuale di parate originale, mostrata solo per un singolo portiere |
| GK Goals Against / 90 | Gol subiti per 90 minuti originali, mostrati solo per un singolo portiere |
| Anno contrattuale, piede, altezza e nazionalità | Informazioni descrittive; l’anno contrattuale è storico e non certifica la disponibilità attuale |

Per le statistiche ordinarie:

`Statistica per 90 = 90 × somma degli eventi / somma dei minuti`

Gli aggregati derivano dai totali, evitando la media semplice dei rate individuali. Dribbling, passaggi chiave e contrasti esterni usano i minuti dello staging e soltanto le righe con numeratore disponibile e denominatore valido.

Le percentuali di passaggi e duelli sono calcolate da conteggi con copertura coerente. `DIVIDE` restituisce vuoto quando il denominatore non è valido. I dati mancanti non diventano zero e i campi specifici dei portieri non vengono interpretati come prestazioni nulle dei giocatori di movimento.

La percentuale di parate non viene aggregata tra più portieri, poiché mancano i conteggi necessari per ponderarla correttamente.

Il fatto conserva anche partenze da titolare, gol non su rigore, tiri nello specchio, intercetti esterni, percentuale di porte inviolate e campi xG/xA. La presenza nel CSV non implica l’impiego in una misura visibile o nell’indice V17. **xG e xA non sono usati nelle misure del report**, perché la loro copertura non è stata riconciliata; i passaggi progressivi non sono disponibili.

## KPI, classifiche e benchmark

- **Players, Teams e Leagues:** conteggi distinti delle chiavi nel contesto dei filtri, per evitare doppi conteggi.
- **Score medi:** medie dei punteggi dei candidati filtrati; non rappresentano l’intero campionato.
- **Market Value:** somma, media o mediana delle valutazioni, secondo il KPI indicato. La somma non è un preventivo di acquisto.
- **Performance per EUR m:** rapporto tra Performance Score e valore di mercato per un singolo giocatore; indicatore distinto dal Value Score.
- **Role Rank:** classifica dinamica per Performance Score tra i candidati dello stesso ruolo inclusi nei filtri. Gli ex aequo condividono il rango.
- **Top 10 Rank:** classifica basata sui percentili performance; gli ex aequo al decimo rango possono produrre più di dieci nomi.
- **Role Benchmark:** media fissa del Performance Score dei candidati V17 dello stesso macroruolo. Le componenti V10 sono confrontate con la media della stessa componente e dello stesso ruolo.
- **Performance vs Role:** scostamento dal benchmark di ruolo, espresso in punti.
- **Young High Performers:** filtro descrittivo per età inferiore a 24 anni e percentile performance almeno 80; non è una previsione del potenziale futuro.
- **Player Comparison:** confronto indipendente dei due giocatori selezionati, con differenze di età e valore. Le differenze sportive vanno interpretate considerando i ruoli.
- **Player Strengths:** le due componenti V10 più alte del profilo, senza attribuire abilità non osservate nei dati.

Il benchmark fisso dei 238 candidati e i percentili del riferimento storico sono grandezze diverse: il primo descrive il pool selezionato, i secondi conservano la posizione nella popolazione originaria del ruolo.

## Pagine del report

| Pagina | Contenuto |
|---|---|
| Il progetto | Obiettivo e popolazione analizzata |
| Il percorso di lavoro | Preparazione dei dati, metodo e limiti |
| Executive Scouting Overview | Composizione del pool e principali KPI |
| Player Scouting & Shortlist | Filtri, classifiche e selezione dei candidati |
| Player Comparison | Confronto tra due profili |
| Moneyball & Transfer Opportunities | Esplorazione di qualità sportiva e valore di mercato |
| Player Detail | Indicatori e componenti del singolo giocatore |

## Controlli e limiti

Il lavoro comprende controlli su unicità degli ID, copertura delle unioni, valori mancanti, corrispondenza tra CSV e database, formule degli indici e quote. Ranking e misure sono stati confrontati con ricalcoli indipendenti.

La consegna comprende il report e i dati necessari alla consultazione; non include l’intero archivio storico o tutti gli script di preparazione.

La stagione di riferimento è la **2025/26**. I risultati descrivono lo snapshot disponibile, senza aggiornamento continuo o ricostruzione temporale delle singole partite. Gli score V10 e le statistiche avanzate mantengono i limiti sperimentali delle fonti.

Mancano informazioni complete su salari, infortuni, condizioni di trasferimento e compatibilità con uno specifico sistema di gioco. I valori di mercato sono stime storiche, distinte sia dai corrispettivi effettivi di trasferimento sia dalle stime statistiche del valore atteso.

Le selezioni individuano priorità di approfondimento e non costituiscono previsioni del rendimento futuro o raccomandazioni definitive di acquisto.
